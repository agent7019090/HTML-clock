# Block Clock

A Pen created on CodePen.

Original URL: [https://codepen.io/ekfuhrmann/pen/XWNZrqQ](https://codepen.io/ekfuhrmann/pen/XWNZrqQ).

Inspired by the black_clock wallpaper on Steam's Wallpaper Engine, this is  a similarly animated clock developed for the front-end. 